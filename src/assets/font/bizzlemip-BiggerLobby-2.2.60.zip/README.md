
# BiggerLobby V2.2.6

Thank you guys for three hundred downloads! It really means alot! I'm really glad I could make something so many people enjoyed.

## Roadmap

Optimization

Dynamic voice chat culling

Dynamic VOIP sample rate.

## Change Log

BiggerLobby servers are now more distinguished in the serverlist. This version is cross compatible with all 2.2.5 versions, so there is no immediate need to upgrade.

More issues fixed regarding stability as a whole, dynamic player patching was removed in favor of stability, as it seemed the patching was inconsistent.

Issue fixed with ending a match! Really sorry about that guys, somehow the issue never showed up at all during testing, and only appeared after I released the update. Such is the way of the modder XD


~~50~~ 40 max players!  
SO many bugfixes relating to stability!  
Internal networking reworked!  
Issues with time not changing / enemies not spawning fixed!  
Playerlist can now display up to 50 players!

[Discord Server](https://discord.gg/lcmods)